
public class Billeteraelectronica {

	
	double saldo; 
	
	public Billeteraelectronica() {
		this.saldo = 0.0;
	}

	public void depositar(double cantidad) {
		this.saldo += cantidad;
		System.out.println("Depósito exitoso. Nuevo capital: " + this.saldo);
	}
	
	public void retirar(double cantidad) {
		if (cantidad > this.saldo) {
			System.out.println("No puedes retirar más dinero del que tienes en la billetera");
		} 
		else {
		this.saldo -= cantidad;
		System.out.println("Retiro exitoso. Nuevo capital: " + this.saldo);
		}
	}
	
	public void mostrarSaldo() {
		System.out.println("Tu saldo actual es: " + this.saldo);
	}
	
}
