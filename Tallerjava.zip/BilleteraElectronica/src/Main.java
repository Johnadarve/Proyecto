import java.util.Scanner;

public class Main {

	public static void main(String[] args, Object billetera1) {
		// TODO Auto-generated method stub

		Scanner scanner = new Scanner(System.in);
		
		Billeteraelectronica billetera11 = new Billeteraelectronica();
		
		
		int opcion = 0; 
		while (opcion != 4){
			System.out.println("------Billetera Electronica--------");
            System.out.println("1. Depositar dinero");
            System.out.println("2. Retirar dinero");
            System.out.println("3. Ver saldo");
            System.out.println("4. Salir");
            System.out.print("Ingrese la opción deseada: ");
            
            opcion = scanner.nextInt();
            
            switch (opcion) {
            case 1:
                System.out.print("Ingrese la cantidad a depositar: ");
                double deposito = scanner.nextDouble();
                billeteraDepositar(billetera11, deposito);
                break;
            case 2:
                System.out.print("Ingrese la cantidad a retirar: ");
                double retiro = scanner.nextDouble();
                billeteraRetirar(billetera11, retiro);
                break;
            case 3:
                billeteraMostrarSaldo(billetera11);
                break;
            case 4:
                System.out.println("Saliendo del programa...");
                break;
            default:
                System.out.println("Opción inválida. Por favor ingrese una opción válida.");
                break;
        }
    }

        scanner.close();
		

		
	}

	private static void billeteraMostrarSaldo(Billeteraelectronica billetera1) {
		// TODO Auto-generated method stub
		
	}

	private static void billeteraRetirar(Billeteraelectronica billetera1, double retiro) {
		// TODO Auto-generated method stub
		
	}

	private static void billeteraDepositar(Billeteraelectronica billetera1, double deposito) {
		// TODO Auto-generated method stub
		
	}

}
