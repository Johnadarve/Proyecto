import java.util.Scanner;


public class Butic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("****Butic****");
		
		// instanciar la clase Producto:
		String referencia = "FV4528";
		String tipodeproducto = "Camiseta";
		String color = "Rojo";
		String talla = "S";
		String genero = "F";
		double precio = 12000;
		String material = "Algodon";
		int stock = 12;	
		Scanner leer = new Scanner(System.in);
		
		System.out.println("Ingrese la referencia: ");
		referencia = leer.nextLine();
		
		System.out.println("Ingrese el tipo de producto: ");
		tipodeproducto = leer.nextLine();
		
		System.out.println("Ingrese el color: ");
		color = leer.nextLine();
		
		System.out.println("Ingrese la talla del producto: ");
		talla = leer.nextLine();
		
		System.out.println("Ingrese el genero del producto: ");
		genero = leer.nextLine();
		
		System.out.println("Ingrese el precio del producto: ");
		precio = leer.nextDouble();
		
		System.out.println("Cantidad de producto: ");
		stock = leer.nextInt();
		
		System.out.println("Ingrese el material en el cual esta fabricado: ");
		material = leer.nextLine();
		
		
		Producto Producto1 = new Producto (referencia,tipodeproducto,color,talla,genero,precio,material,stock);
		System.out.println(Producto1);
		
		// Llamar metodos de la clase producto
		Producto1.insertarProducto();
		Producto1.actualizarProducto();
		Producto1.consultarProducto();
		Producto1.cambiarestadoProducto();
		
		leer.close();	
	}
	
}
	
		
		
				
				
