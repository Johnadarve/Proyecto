//import java.util.Date;

public class Producto {
// 1. Definir atributos 
	String referencia;
	String tipodeproducto;
	String color;
	String talla;
	String genero;
	double precio;
	String material;
	int stock;
	
// 2. Definir el constructor de la clase 
	Producto(String referencia,String tipodeproducto,String color,String talla,
			String genero,double precio,String material,int stock){
		this.referencia = referencia;
		this.tipodeproducto = tipodeproducto;
		this.color = color;
		this.talla = talla;
		this.genero = genero;
		this.precio = precio;
		this.material = material;
		this.stock = stock;}
		
// 3. Metodos SET
		public void setreferencia(String referencia) { 
			this.referencia = referencia;
			}
		public void setretipodeproducto(String tipodeproducto) { 
			this.tipodeproducto = tipodeproducto;
			}
		public void setrecolor(String color) { 
			this.color = color;
			}
		public void setretalla(String talla) { 
			this.talla = talla;
			}
		public void setgenero(String genero) { 
			this.genero = genero;
			}
		public void setprecio(double precio) { 
			this.precio = precio;
			}
		public void setmaterial(String material) { 
			this.material = material;
			}
		public void setstock(int stock) { 
			this.stock = stock;
			}

//Definir metodos GET 
		public  String getreferencia() { 
			return this.referencia;
			}
		public  String gettipodeproducto() { 
			return this.tipodeproducto;
			}
		public  String getcolor() { 
			return this.color;
			}
		public  String gettalla() { 
			return this.talla;
			}
		public  String getgenero() { 
			return this.genero;
			}
		public  double getprecio() { 
			return this.precio;
			}
		public  String getmaterial() { 
			return this.material;
			}
		public  int getstock() { 
			return this.stock;
			}

// Agregar otros metodos 
		
		public void insertarProducto() {
			System.out.println("El Producto fue insertado correctamente");
			}
		public void actualizarProducto() {
			System.out.println("El Producto fue actualizado correctamente");
			}
		public void consultarProducto() {
			System.out.println("El Producto fue consultado correctamente");
			}
		public void cambiarestadoProducto() {
			System.out.println("El Producto fue cambiado correctamente");
			}
		
		@Override
		public String toString() {
			return "producto\n referencia: "+ this.referencia+
					"\n tipo de producto: "+ this.tipodeproducto+
					"\n color: "+ this.color+
					"\n talla: "+ this.talla+
					"\n genero:"+ this.genero+
					"\n precio: "+ this.precio+
					"\n material:"+ this.material+
					"\n stock: "+ this.stock;
				 
					
					}
		
		

}
