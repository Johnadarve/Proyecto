import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner leer = new Scanner(System.in);
        System.out.print("Ingrese la cantidad de pesos a convertir: ");
        double pesos = leer.nextDouble();

        Conversor conversor = new Conversor(pesos);

        //  conversiones
        double dolares = conversor.convertirDolares();
        double euros = conversor.convertirEuros();

        // Imprimir  valores 
        System.out.println("Cantidad en dólares: $" + dolares);
        System.out.println("Cantidad en euros: €" + euros);
        leer.close();
         
	}

}
