
public class Apartamento extends Inmueble {
	String ubicacion;
	
	public Apartamento(int codigo,String ciudad,String direccion,double area,double valorMt2,double valorMensual,String zona,String ubicacion) {
		super (codigo,ciudad,direccion,area,valorMt2,valorMensual,zona);
	}

	public String getUbicacion() {
		return ubicacion;
	}

	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}
	

}
