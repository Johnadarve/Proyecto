
public class Casa extends Inmueble {
	public Casa(int codigo,String ciudad,String direccion,
			double area,double valorMt2,double valorMensual,String zona) {
		super (codigo,ciudad,direccion,area,valorMt2,valorMensual,zona);
	}
}


