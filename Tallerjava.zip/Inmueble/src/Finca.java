
class Finca extends Inmueble {
	public Finca(int codigo,String ciudad,String direccion,double area,double valorMt2,double valorMensual,String zona) {
		super (codigo,ciudad,direccion,area,valorMt2,valorMensual,zona);
	}
}
