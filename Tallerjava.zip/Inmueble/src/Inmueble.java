
public abstract class Inmueble {

	// 1. Definir atributos

	int codigo;
	String ciudad;
	String direccion;
	double area;
	double valorMt2;
	double valorMensual;
	public String zona;
	

	// 2. Definir el constructor
	Inmueble(int codigo, String ciudad, String direccion, double area, double valorMt2, double valorMensual,String zona) {
		this.codigo = codigo;
		this.ciudad = ciudad;
		this.direccion = direccion;
		this.area = area;
		this.valorMt2 = valorMt2;
		this.valorMensual = valorMensual;
		this.zona = zona;
	}

	// metodos getter y setter
	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public double getArea() {
		return area;
	}

	public void setArea(double area) {
		this.area = area;
	}

	public double getValorMt2() {
		return valorMt2;
	}

	public void setValorMt2(double valorMt2) {
		this.valorMt2 = valorMt2;
	}

	public double getValorMensual() {
		return valorMensual;
	}

	public void setValorMensual(double valorMensual) {
		this.valorMensual = valorMensual;

	}
	public String getZona() {
		return zona;
	}

	public void setZona(String Zona) {
		this.zona = zona;
	}
	
	
	// Método para calcular valor venta en pesos

	int calcularValorVenta() {
		return (int) (area * valorMt2);
	}

	double calcularValorVenta(double dollar) {
		return (double) (area * valorMt2)/dollar;

	}

	// Método para calcular avalúo en pesos
	int calcularAvaluoCatastral() {
		double porcentaje = (zona.equals("urbana")) ? 0.7 : 0.6;
		return (int) (calcularValorVenta() * porcentaje);
	}

}
