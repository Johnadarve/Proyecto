
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Casa Casa1 = new Casa(123, "Medellin", "cra 12", 54, 25400, 300,"urbana");
		//calcularValorVenta
		System.out.println("este es el valor de la casa: \n" + Casa1.calcularValorVenta() );
		System.out.println("este es el valor de la casa: \n" + Casa1.calcularValorVenta(4000) );
		System.out.println("este es el valor del avaluo zona urbana: \n"+ Casa1.calcularAvaluoCatastral());
	

	}

}
