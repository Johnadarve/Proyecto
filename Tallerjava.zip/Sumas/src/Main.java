
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

        Sumador sumadorEnteros = new Sumador();
        SumadorFlotante sumadorFlotantes = new SumadorFlotante();
        SumadorDouble sumadorDoubles = new SumadorDouble();

        // Suma de enteros
        int sumaEnteros = sumadorEnteros.sumar(5, 10, 15);
        System.out.println("Suma de enteros: " + sumaEnteros);

        // Suma de flotantes
        float sumaFlotantes = sumadorFlotantes.sumar(3.5f, 2.7f, 1.8f);
        System.out.println("Suma de flotantes: " + sumaFlotantes);

        // Suma de doubles
        double sumaDoubles = sumadorDoubles.sumar(10.5, 20.7, 30.9);
        System.out.println("Suma de doubles: " + sumaDoubles);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
