
public class SumadorDouble {
    public double sumar(double num1, double num2, double num3) {
        return num1 + num2 + num3;
    }
}
