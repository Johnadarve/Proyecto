
public class SumadorFlotante {
    public float sumar(float num1, float num2, float num3) {
        return num1 + num2 + num3;
    }
}
