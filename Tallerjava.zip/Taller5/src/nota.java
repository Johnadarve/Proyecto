
public class nota {
	String documento;
	String asignatura;
	double nota60;
	double nota40;

	// definimos el constructor de la clase
	public nota(String documento, String asignatura, double nota60, double nota40) {
		this.documento = documento;
		this.asignatura = asignatura;
		this.nota60 = nota60;
		this.nota40 = nota40;

	}

	// metodos set
	public void setDocumentos(String documento) {
		this.documento = documento;
	}

	public void setAsignatura(String asignatura) {
		this.asignatura = asignatura;
	}

	public void setnota60(double nota60) {
		this.nota60 = nota60;
	}

	public void setnota40(double nota40) {
		this.nota40 = nota40;
	}

	// definimos metodos getter
	public String getdocumentos() {
		return this.documento;
	}

	public String getasignatura() {
		return this.asignatura;
	}

	public double getnota60() {
		return this.nota60;
	}

	public double getnota40() {
		return this.nota40;
	}

	public double NotaFinal() {
		return nota60 * 0.6 + nota40 * 0.4;
	}

	public boolean aprobar() {
		return NotaFinal() >= 3.0;
	}
	 @Override
	 public String toString() {
	     return "Documento: " + documento +
	             "\nAsignatura: " + asignatura +
	             "\nNota Final: " + NotaFinal() +
	             "\nAprobado: " + (aprobar() ? "Sí" : "No"); 
	     // operador ternario, forma abreviada  instrucción if-else


	}
	
	  
	    

}



